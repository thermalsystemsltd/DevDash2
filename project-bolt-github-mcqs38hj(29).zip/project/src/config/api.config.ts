export const API_CONFIG = {
  baseURL: 'https://gateway.icespyonline.com',
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  },
  withCredentials: true
};